﻿using Newtonsoft.Json;
using WikiImporter;

Console.WriteLine("Read settings");
var settings = JsonConvert.DeserializeObject<Settings>(File.ReadAllText(".\\settings.json"));

Console.WriteLine("Start syncing...");
GithubPagesSyncer.Sync(
    settings.RepoUrl,
    settings.GithubPersonalToken,
    settings.GithubFromFolder,
    settings.GraphQlUrl,
    settings.WikiAccessToken,
    settings.Locale,
    settings.WikiFolder
);

Console.WriteLine("Done");