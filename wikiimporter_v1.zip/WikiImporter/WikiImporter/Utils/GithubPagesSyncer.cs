﻿using System.IO.Compression;

namespace WikiImporter;

public class GithubPagesSyncer {
    private static string githubRepo = "./repo.zip";
    private static string localRepo = ".\\repo\\";
    
    public static void Sync(string repoUrl, string personalToken, string fromFolder, string graphQlUrl, string accessToken, string locale, string wikiFolder) {
        Console.WriteLine("Downloading github repo");
        GithubRepoDownloader.DownloadAsZip(repoUrl, personalToken, githubRepo);

        Console.WriteLine("Extracting repo");
        ZipFile.ExtractToDirectory(githubRepo, localRepo, true);
        ProcessDirectory(localRepo, fromFolder, graphQlUrl, accessToken, locale, wikiFolder);        
    }
    
    private static void ProcessDirectory(string path, string startFolder, string graphQlUrl, string accessToken, string locale, string wikiFolder){
        Console.WriteLine("processing dir: " + path);
        var dirs = Directory.GetDirectories(path);
        foreach (var dir in dirs) {
            ProcessDirectory(dir, startFolder, graphQlUrl, accessToken, locale, wikiFolder);
        }

        var files = Directory.GetFiles(path, "*.md");
        foreach (var file in files) {
            var searchPattern = $"\\{startFolder}\\";
            var startIndex = file.IndexOf(searchPattern);
            if (startIndex > 0) {
                var fileContent = File.ReadAllText(file);
                var pathToFile = file.Substring(startIndex + searchPattern.Length, file.Length - startIndex - searchPattern.Length)
                    .Replace("\\", "/")
                    .Replace(".md", "");
                    
                WikiPageCreator.Create(graphQlUrl, accessToken, locale,$"{wikiFolder}/{pathToFile}", fileContent);
            }
        }
    }
}