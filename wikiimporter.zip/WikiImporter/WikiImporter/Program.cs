﻿using Newtonsoft.Json;
using WikiImporter;

Console.WriteLine("Read settings");
var settings = JsonConvert.DeserializeObject<Settings>(File.ReadAllText(".\\settings.json"));

Console.WriteLine("Start syncing...");
GithubPagesSyncer.Sync(
    settings.RepoUrl,
    settings.GithubPersonalToken,
    settings.GithubFromFolder,
    settings.GraphQlUrl,
    settings.WikiAccessToken,
    settings.Locale,
    settings.WikiFolder
);

Console.WriteLine("Done");



// var schema = WikiJSSchema.Create();
// schema.Authorize();
// var res = schema
//     .ExecuteAsync(null, _ => _.Query = "query page { pages { list { id, path } } }" )
//     .Result;

// var root = new { Hello = "Hello World!" };
// var json = schema.Mutation();
//
// Console.WriteLine(json);