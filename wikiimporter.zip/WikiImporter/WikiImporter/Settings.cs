﻿namespace WikiImporter;

public class Settings {
    public string RepoUrl { get; set; }
    public string GithubPersonalToken { get; set; }
    public string GithubFromFolder  { get; set; }
    public string GraphQlUrl  { get; set; }
    public string WikiAccessToken  { get; set; }
    
    public string Locale  { get; set; }
    public string WikiFolder  { get; set; }
}