﻿using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.Newtonsoft;

namespace WikiImporter;

public static class WikiPageCreator {
    private static string QUERY =
        @"
mutation Page ($content: String!, $description: String!, $editor:String!, $isPublished:Boolean!, $isPrivate:Boolean!, $locale:String!, $path:String!, $title:String!) {
  pages {
    create (content:$content, description:$description, editor: $editor, isPublished: $isPublished, isPrivate: $isPrivate, locale: $locale, path:$path, tags: [], title:$title) {
      responseResult {
        succeeded,
        errorCode,
        slug,
        message
      },
      page {
        id,
        path,
        title
      }
    }
  }
}";
    public static void Create(string graphQlUrl, string accessToken, string locale, string pagePath, string content) {
        Console.WriteLine("Creating page: " + pagePath);
        var client = new GraphQLHttpClient(graphQlUrl,new NewtonsoftJsonSerializer());
        client.HttpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);

        var lastSlashIndex = pagePath.LastIndexOf("/");
        var title = pagePath.Substring(lastSlashIndex + 1, pagePath.Length - lastSlashIndex - 1);
        
        var request = new GraphQLRequest {
            Query = QUERY, Variables = new {
                content, 
                description = "", 
                editor = "markdown", 
                isPublished = true, 
                isPrivate = false, 
                locale, 
                path = $"{pagePath}", 
                title                              
            }
        };

        var res = client.SendQueryAsync<dynamic>(request).Result;
        if (res.Errors?.Length > 0) {
            throw new ApplicationException(res?.Errors[0].Message);
        }
        Thread.Sleep(500);        
        Console.WriteLine("page created successfully");
    }
}