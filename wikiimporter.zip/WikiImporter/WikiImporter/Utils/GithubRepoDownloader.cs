﻿namespace WikiImporter;

public static class GithubRepoDownloader {
    public static void DownloadAsZip(string pathToRepo, string pesonalToken, string outputPath) {
        var url = $"{pathToRepo}/archive/master.zip";
        using (var client = new HttpClient()) {
            var credentials = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}:", pesonalToken);
            credentials = Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(credentials));
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);
            
           var contents = client.GetByteArrayAsync(url).Result;
            File.WriteAllBytes(outputPath, contents);
        }
    }
}